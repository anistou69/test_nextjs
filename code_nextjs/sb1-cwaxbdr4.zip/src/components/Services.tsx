import React from 'react';
import ServiceCard from './ServiceCard';

const services = [
  {
    title: "ENCOMBRANTS",
    description: "Évacuation d'encombrants pour particuliers et professionnels",
    image: "https://images.unsplash.com/photo-1532323544230-7191fd51bc1b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
  },
  {
    title: "NETTOYAGE",
    description: "Nettoyage d'immeubles, bureaux et logements",
    image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
  },
  {
    title: "CONTAINERS",
    description: "Rotation et gestion des containers",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
  },
  {
    title: "PRESTATIONS SUR DEVIS",
    description: "Désinfection, lavage de vitres, nettoyage de tapis et plus",
    image: "https://images.unsplash.com/photo-1527515862127-a4fc05baf7a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-bilanis-gray">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-bilanis-darkBlue mb-12">
          NOS SERVICES
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              {...service}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;