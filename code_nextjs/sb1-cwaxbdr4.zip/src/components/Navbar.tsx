import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { title: 'QUI SOMMES NOUS ?', href: '#about' },
    { title: 'NOS SERVICES', href: '#services' },
    { title: 'NEWS & ACTU', href: '#news' },
    { title: 'CARRIÈRE', href: '#career' },
    { title: 'NOS RÉFÉRENCES', href: '#references' },
    { title: 'CONTACT', href: '#contact' }
  ];

  return (
    <nav className="bg-white shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <img src="/logo.svg" alt="Bilanis Propreté" className="h-12" />
          </div>
          
          <div className="hidden md:flex space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.title}
                href={item.href}
                className="text-bilanis-blue hover:text-bilanis-green font-montserrat font-semibold"
              >
                {item.title}
              </a>
            ))}
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? (
                <X className="h-6 w-6 text-bilanis-blue" />
              ) : (
                <Menu className="h-6 w-6 text-bilanis-blue" />
              )}
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {menuItems.map((item) => (
                <a
                  key={item.title}
                  href={item.href}
                  className="block px-3 py-2 text-bilanis-blue hover:text-bilanis-green font-montserrat font-semibold"
                >
                  {item.title}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;