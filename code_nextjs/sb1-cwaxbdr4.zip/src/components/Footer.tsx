import React from 'react';
import { Sparkles } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Sparkles className="h-6 w-6 text-blue-400" />
              <span className="ml-2 text-lg font-bold">CleanPro Services</span>
            </div>
            <p className="text-gray-400">
              Solutions professionnelles de nettoyage pour entreprises et particuliers
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li><a href="#accueil" className="text-gray-400 hover:text-white">Accueil</a></li>
              <li><a href="#presentation" className="text-gray-400 hover:text-white">Présentation</a></li>
              <li><a href="#prestations" className="text-gray-400 hover:text-white">Prestations</a></li>
              <li><a href="#devis" className="text-gray-400 hover:text-white">Devis</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Horaires</h3>
            <p className="text-gray-400">
              Lundi - Vendredi : 8h00 - 18h00<br />
              Samedi : 9h00 - 12h00<br />
              Dimanche : Fermé
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} CleanPro Services. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;